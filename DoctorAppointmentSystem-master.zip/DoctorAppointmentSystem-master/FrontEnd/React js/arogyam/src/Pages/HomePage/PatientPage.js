
const PatientPage =()=>{
    return(
        <>
        <h1>Inside Patient Page</h1>
        
        </>
    )
}

export default PatientPage;