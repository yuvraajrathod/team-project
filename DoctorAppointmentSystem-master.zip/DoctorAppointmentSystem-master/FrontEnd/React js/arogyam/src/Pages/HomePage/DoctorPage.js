
import DoctorLayout from "./DoctorFolder/DoctorLayout";
const DoctorPage =()=>{
    return(
        <>
        <h1>Inside DoctorPage Page</h1>
        <DoctorLayout />
        </>
    )
}

export default DoctorPage;