import HomepageLayout from "./HomePage/HomePagelayout";

const Home =()=>{
    return(
        <>
      <HomepageLayout/>
        </>

    )
}
 export default Home;