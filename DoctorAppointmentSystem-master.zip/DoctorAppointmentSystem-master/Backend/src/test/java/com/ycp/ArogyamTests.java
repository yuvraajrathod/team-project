package com.ycp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArogyamTests {

	@Test
	void contextLoads() {
	}

}
