package com.ycp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Arogyam {

	public static void main(String[] args) {
		SpringApplication.run(Arogyam.class, args);
	}
}
