package com.ycp.Classes;
public enum Rating {
	BEST,GOOD,BAD;
}
